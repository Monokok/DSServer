

import React, { Component } from "react";
import ErrorPage from './ErrorPage';


class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  componentDidCatch(error, errorInfo) {
    // Здесь обработка ошибки
    console.error("ErrorBoundary поймал ошибку:", error, errorInfo);
    this.setState({ hasError: true });
  }

  render() {
    if (this.state.hasError) {
      return <ErrorPage></ErrorPage>; // Отображение резервного контента
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
